// Custom command for login
Cypress.Commands.add('login', (email, password) => {
  cy.get('input[type="email"]').type(email)
  cy.get('input[type="password"]').type(password)
  cy.get('button[type="submit"]').click()
})

describe('Teste da pagina de Login', () => {
  beforeEach(() => {
    cy.visit('http://localhost:5173/login')
  })

  it('deve mostrar os elementos do form corretamente', () => {
    cy.get('input[type="email"]').should('be.visible')
    cy.get('input[type="password"]').should('be.visible')
    cy.get('button[type="submit"]').should('be.visible')
    cy.contains('Login').should('be.visible')
  })

  it('deve mostrar um erro quando fazer login com usuario e senha inválidos', () => {
    cy.login('wrong@email.com', 'wrongpassword')
    cy.get('.message').should('contain', 'Erro ao realizar login')
    cy.url().should('include', '/login')
  })

  it('deve fazer login com usuario e senha válidas', () => {
    cy.login('user@example.com', '123456')
    cy.url().should('include', '/')
    cy.get('.message').should('contain', 'Login feito.')
  })

  // Using custom command in another test
  it('deve redirecionar para a pagina incial após login válido', () => {
    cy.login('user@example.com', '123456')
    cy.url().should('include', '/')
    cy.get('.home-page').should('exist')
  })
})

describe('Teste da pagina de tarefas', () => {
  beforeEach(() => {
    cy.visit('http://localhost:5173/login')
    cy.login('user@example.com', '123456')
    cy.url().should('include', '/')
  });
  it('deve mostrar corretamente os elementos da pagina', () => {
    cy.get('.task-form').should('be.visible')
    cy.get('input[name="titulo"]').should('be.visible')
    cy.get('textarea[name="descricao"]').should('be.visible')
    cy.get('select').should('be.visible')
    cy.get('.task-form button[type="submit"]').should('be.visible')
  })

  it('deve criar uma nova tarefa corretamente', () => {
    const taskTitle = 'Test Task'
    const taskDescription = 'Test Description'
    
    cy.get('input[name="titulo"]').type(taskTitle)
    cy.get('textarea[name="descricao"]').type(taskDescription)
    cy.get('select[name="status"]').select('pendente')
    cy.get('.task-form button[type="submit"]').click()
    
    cy.get('.tasks-list').should('contain', taskTitle)
  })

  it('deve validar os inputs do formulario', () => {
    cy.get('.task-form button[type="submit"]').click()
    cy.get('input[name="titulo"]:invalid').should('exist')
    cy.get('textarea[name="descricao"]:invalid').should('exist')
  })
})