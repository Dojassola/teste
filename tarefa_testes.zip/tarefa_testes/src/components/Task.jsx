import React from "react";
import axios from "axios";

export default function Task({ id, titulo, descricao, status, listar }) {

  const handleStatusChange = async (e) => {
    const novoStatus = e.target.value;
    try {
      const token = localStorage.getItem("token");
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      // Enviando apenas id e novo status
      await axios.put("http://localhost:3000/tarefa", {
        id: id,
        status: novoStatus
      }, config);

      listar(); // Atualiza lista após alteração
    } catch (error) {
      console.error("Erro ao atualizar status:", error);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Tem certeza que deseja excluir esta tarefa?")) return;
    try {
      const token = localStorage.getItem("token");
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };
      await axios.delete(`http://localhost:3000/tarefa/${id}`, config);
      listar(); // Atualiza lista após exclusão
    } catch (error) {
      console.error("Erro ao excluir tarefa:", error);
    }
  };

  return (
    <div className="task-card">
      <h2 className="task-title">{titulo}</h2>
      <p className="task-description">{descricao}</p>
      <div>
        <label>Status:</label>
        <select 
          name="select"
          value={status}
          onChange={handleStatusChange}
        >
          <option value="pendente">Pendente</option>
          <option value="em andamento">Em Andamento</option>
          <option value="concluído">Concluído</option>
        </select>
      </div>
      <button onClick={handleDelete} className="delete-button">🗑️ Excluir</button>
    </div>
  );
}