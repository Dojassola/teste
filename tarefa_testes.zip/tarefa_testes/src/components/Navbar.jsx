import { Link } from 'react-router-dom';

function Navbar({ user, onLogout }) {
  return (
    <nav className="navbar">
      <div className="nav-brand">
        {user ? <span>Bem vindo, {user}</span> : <span>Gerenciador de Tarefas</span>}
      </div>
      <div className="nav-links">
        {user ? <>
            <Link to="/">Tarefas</Link>
            <button onClick={onLogout} className="botao-logout">Logout</button>
          </> : <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        }
      </div>
    </nav>
  );
}

export default Navbar; 