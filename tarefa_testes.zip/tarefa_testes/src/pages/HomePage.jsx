import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';
import Task from '../components/Task';
function HomePage() {
  const [tarefas, setTarefas] = useState([]);
  const [username, setUsername] = useState('');
  const [novaTarefa, setNovaTarefa] = useState({
    id: Number,
    titulo: '',
    descricao: '',
    status: 'pendente'
  }); // aqui usar valor default para as tarefas pra nao dar null
  const navigate = useNavigate();
  
  useEffect(() => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (!token) {
      navigate('/login');
    } else {
      setUsername(user);
      listarTarefas();
    }
  }, [navigate]);

  async function listarTarefas() {
    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: {
          'Authorization': `Bearer ${token}`
        } // aqui usar config pra melhor organizar se eu precisar mudars
      };
      const retorno = await axios.get('http://localhost:3000/tarefa', config);
      setTarefas(retorno.data.tarefas);
    } catch (error) {
      console.error('Erro ao listar tarefas:', error);
    }
  }
  async function criarTarefa(e) {
    e.preventDefault(); // usar isso pra impedir o recarregamento da pagina
    try {
      const token = localStorage.getItem('token'); // usar o token do local storage que eu tinha esquecido AAAAAAAA
      const config = {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      };
      await axios.post('http://localhost:3000/tarefa', novaTarefa, config);
      setNovaTarefa({
        titulo: '',
        descricao: '',
        status: 'pendente'
      }); // tem que resetar o valor da tarefa senao da ruim
      listarTarefas();
    } catch (error) {
      console.error('Erro kkkkkkkk:', error);
    }
  }

  const handleInputChange = (e) => { // funcao basica pra alterar os valores da tarefa
    const { name, value } = e.target;
    setNovaTarefa(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleLogout = () => { // basico pra fazer o logout
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div className="home-page">
      <Navbar user={username} onLogout={handleLogout} />
      <form onSubmit={criarTarefa} className="task-form">
          <h3>Adicionar Nova Tarefa</h3>
          <div>
            <label>Título:</label>
            <input
              type="text"
              name="titulo"
              value={novaTarefa.titulo}
              onChange={handleInputChange}
              required
            />
          </div>
          <div>
            <label>Descrição:</label>
            <textarea
              name="descricao"
              value={novaTarefa.descricao}
              onChange={handleInputChange}
              required
            ></textarea>
          </div>
          <div>
            <label>Status:</label>
            <select
              name="status"
              value={novaTarefa.status}
              onChange={handleInputChange}
            >
              <option value="pendente">Pendente</option>
              <option value="em andamento">Em Andamento</option>
              <option value="concluído">Concluído</option>
            </select>
          </div>
          <button type="submit">Adicionar Tarefa</button>
        </form>
      <div className="tasks-container">
      <h2>Minhas Tarefas</h2>
        <div className="tasks-list">
          {tarefas.length === 0 ? 
            <p>Nao tem tarefa man</p> : 
            tarefas.map((tarefa) =>
            <Task key={tarefa.id} {...tarefa} listar={listarTarefas} />
            )
          }
        </div>
      </div>
    </div>
  );
}

export default HomePage; 