import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';

function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginMessage, setLoginMessage] = useState('');

  const navigate = useNavigate(); // usar navigate nao esquecer
  async function loginUsuario(e) {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3000/auth/login', {
        email: username,
        senha: password,
      });
      
      setLoginMessage('Login feito.');
      console.log(  response.data);
      localStorage.setItem('token', response.data.token); // puxar o token e o user pra usar e nao destruir o site
      localStorage.setItem('user', response.data.user?.nome || username);
      setTimeout(() => {
        navigate('/');
      }, 2000); // usar o timeout pra guardar o token
    } catch (error) {
      setLoginMessage('Erro ao realizar login. Verifique suas credenciais.');
      console.error(error);
    }
  }

  return (
    <div className="login-page">
      <Navbar/>
      
      <div className="auth-container">
        <h2>Login</h2>
        
        <form onSubmit={loginUsuario} className="auth-form">
          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label>Senha:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <button type="submit" className="auth-button">Entrar</button>
          
          {loginMessage && <p className="message">{loginMessage}</p>}
          
          <div className="auth-link">
            <p>Se cadastra ai <Link to="/register">Cadastre-se</Link></p>
          </div>
        </form>
      </div>
    </div>
  );
}

export default LoginPage; 