import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';

function RegisterPage() {
  const [newUser, setNewUser] = useState({
    nome: '',
    email: '',
    senha: ''
  }); // usar valores default para evitar bugs na estrutura de preenchimento do form
  const [registerMessage, setRegisterMessage] = useState(''); // aqui usar o registerMessage pra mostrar a mensagem de erro
  const navigate = useNavigate(); // nao esquecer mais do navigate

  async function cadastrarUsuario(e) {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3000/auth/cadastrar', {
        nome: newUser.nome,
        email: newUser.email,
        senha: newUser.senha
      });
      
      if (response.status === 201) {
        setRegisterMessage('Usuario cadastrado.');
        
        setNewUser({ nome: '', email: '', senha: '' });
        setTimeout(() => {
          navigate('/login');
        }, 2000); // usar o timeout pra guardar o token
      } else {
        setRegisterMessage(response.data.mensagem || 'Erro ao cadastrar usuário.');
      }
    } catch (error) {
      setRegisterMessage('Erro ao cadastrar usuário. Tente novamente.');
      console.error(error);
    }
  }

  const handleInputChange = (e) => { // essa função deveria ser default do react
    const { name, value } = e.target;
    setNewUser(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="register-page">
      <Navbar />
      
      <div className="auth-container">
        <h2>Cadastro de Usuário</h2>
        
        <form onSubmit={cadastrarUsuario} className="auth-form">
          <div className="form-group">
            <label>Nome:</label>
            <input
              type="text"
              name="nome"
              value={newUser.nome}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={newUser.email}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Senha:</label>
            <input
              type="password"
              name="senha"
              value={newUser.senha}
              onChange={handleInputChange}
              required
            />
          </div>
          
          <button type="submit" className="auth-button">Cadastrar</button>
          
          {registerMessage && <p className="message">{registerMessage}</p>}
          
          <div className="auth-link">
            <p>Se ja tem conta <Link to="/login">Faça login</Link></p>
          </div>
        </form>
      </div>
    </div>
  );
}

export default RegisterPage; 